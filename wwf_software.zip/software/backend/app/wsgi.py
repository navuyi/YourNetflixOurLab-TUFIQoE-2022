from email.mime import application
from __init__ import create_app

application = create_app()